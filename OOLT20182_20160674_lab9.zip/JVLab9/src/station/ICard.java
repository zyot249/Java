package station;

public interface ICard {
    public void add(int amount);

    public boolean deduct(int amount);
}
